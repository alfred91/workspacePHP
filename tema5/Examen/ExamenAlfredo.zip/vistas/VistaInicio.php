<?php
namespace Examen\vistas;

class VistaInicio
{

    public static function render()
    {

        include("Cabecera.php");


    }
}
